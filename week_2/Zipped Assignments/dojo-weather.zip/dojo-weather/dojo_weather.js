// REMOVES COOKIE POLICY MESSAGE
function dismissMessage(){
    var cookieMessage = document.querySelector(".cookie");
    cookieMessage.remove();
}


// CONVERT TEMPERATURE BETWEEN FAHRENHEIT AND CELSIUS
function changeUnits(element){
    var temp = document.querySelectorAll("#temp");
    // var units = document.querySelector("#unit-select option");
    if(element.value === "°C"){
        for(var i=0; i<temp.length; i++){
            temp[i].innerText = Math.round((temp[i].innerText - 32) / 9*5);
        }
    }
    else if(element.value === "°F"){
        for(var i=0; i<temp.length; i++){
            temp[i].innerText = Math.round(temp[i].innerText * 9/5 + 32);
        }
    }
}